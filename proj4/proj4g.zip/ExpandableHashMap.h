//// ExpandableHashMap.h
//
//// Skeleton for the ExpandableHashMap class template.  You must implement the first six
//// member functions.
//#include <iostream>
//#include <vector>
//#include "provided.h"
//
//template <typename KeyType, typename ValueType>
//class ExpandableHashMap
//{
//public:
//    ExpandableHashMap(double maximumLoadFactor = 0.5);
//    ~ExpandableHashMap();
//    void reset();
//    int size() const;
//    void associate(const KeyType& key, const ValueType& value);
//
//      // for a map that can't be modified, return a pointer to const ValueType
//    const ValueType* find(const KeyType& key) const;
//
//      // for a modifiable map, return a pointer to modifiable ValueType
//    ValueType* find(const KeyType& key)
//    {
//        return const_cast<ValueType*>(const_cast<const ExpandableHashMap*>(this)->find(key));
//    }
//    unsigned int getBucketNumber(const KeyType& key) const;
//      // C++11 syntax for preventing copying and assignment
//    ExpandableHashMap(const ExpandableHashMap&) = delete;
//    ExpandableHashMap& operator=(const ExpandableHashMap&) = delete;
//
//private:
//    //size of this returns the number of buckets in a hashmap
//    struct Node
//    {
//        Node(ValueType tempVal, KeyType tempKey) : m_value(tempVal), m_key(tempKey), m_next(nullptr){}
//        ValueType m_value;
//        KeyType m_key;
//        Node*     m_next;
//
//    };
//    std::vector<Node*> m_values;
//    //std::vector<KeyType> m_keys;
//    //number of keys in the hashmap
//    int m_size;
//    double m_maxLoadFactor;
//};
//
//template <typename KeyType, typename ValueType>
//ExpandableHashMap<KeyType, ValueType>::ExpandableHashMap(double maximumLoadFactor){
//    m_size = 0;
//    if(maximumLoadFactor > 0)
//        m_maxLoadFactor = maximumLoadFactor;
//    else
//        m_maxLoadFactor = 0.5;
//    for(int i = 0; i < 8; i++){
//        //m_keys.push_back(KeyType());
//        m_values.push_back(nullptr);
//    }
//}
//
//template <typename KeyType, typename ValueType>
//unsigned int ExpandableHashMap<KeyType, ValueType>::getBucketNumber(const KeyType& key) const
//{
//    unsigned int hasher(const KeyType& k); // prototype
//    unsigned int h = hasher(key);
//    return h % m_values.size();
//}
//
//
//template <typename KeyType, typename ValueType>
//ExpandableHashMap<KeyType, ValueType>::~ExpandableHashMap()
//{
//    for(int i = 0; i < m_values.size(); i++){
//        //m_keys[i] = KeyType();
//        Node* curr = m_values[i];
//        while(curr !=nullptr){
//            curr = m_values[i]->m_next;
//            delete m_values[i];
//            m_values[i] = nullptr;
//            m_values[i] = curr;
//        }
//        m_values[i] = nullptr;
//    }
//}
//
//template <typename KeyType, typename ValueType>
//void ExpandableHashMap<KeyType, ValueType>::reset()
//{
//    for(int i = 0; i < m_values.size(); i++){
//        //m_keys[i] = KeyType();
//        Node* curr = m_values[i];
//        while(curr !=nullptr){
//            curr = m_values[i]->m_next;
//            delete m_values[i];
//            m_values[i] = nullptr;
//            m_values[i] = curr;
//        }
//        m_values[i] = nullptr;
//    }
//    for(int i = m_values.size()-1; i >=8; i--){
//        //m_keys.push_back();
//        m_values.pop_back();
//    }
//    m_size = 0;
//}
//
//
//template <typename KeyType, typename ValueType>
//int ExpandableHashMap<KeyType, ValueType>::size() const
//{
//    //std::cerr << "NBuckets:   " << m_values.size() << " actsize: ";
//    return m_size;  // Delete this line and implement this function correctly
//}
//
//
//// The associate method associates one item (key) with another (value).
//// If no association currently exists with that key, this method inserts
//// a new association into the hashmap with that key/value pair. If there is
//// already an association with that key in the hashmap, then the item
//// associated with that key is replaced by the second parameter (value).
//// Thus, the hashmap must contain no duplicate keys.
//template <typename KeyType, typename ValueType>
//void ExpandableHashMap<KeyType, ValueType>::associate(const KeyType& key, const ValueType& value)
//{
//
//    //Checks if there is already a node in the hash map with that key
//    //std::cerr << m_size/(double)(m_values.size()) << std::endl;
//    if(this->find(key) != nullptr){
//        *(this->find(key)) = value;
//        return;
//    }
//    m_size++;
//
////    std::vector<Node*> testing = m_values;
////    for(int i = 0; i < testing.size(); i++){
////        Node* curr = m_values[i];
////        Node* currNew = testing[i];
////        while(curr != nullptr){
////            currNew = new Node(curr->m_value,curr->m_key);
////
////            curr = curr->m_next;
////            currNew = currNew->m_next;
////        }
////    }
////    for(int i = testing.size()-1; i>=0; i--){
//////            m_keys.pop_back();
////        Node* curr = testing[i];
////        int j = 0;
////        while(curr != nullptr){
////            delete curr;
////            curr = testing[i]->m_next;
////            testing[i] = testing[i]->m_next;
////            j++;
////        }
////        testing.pop_back();
////    }
//    //Checks if the hash map is hitting the load factor and needs to be rehashed
//    //std::cerr << "LoadFactor: " <<  m_size/(double)(m_values.size()) << std::endl;
//    if(m_size/(double)(m_values.size()) > m_maxLoadFactor){
//        std::cerr <<"Rehashing..." << std::endl;
//        //ExpandableHashMap<KeyType, ValueType> temp = new ExpandableHashMap<KeyType, ValueType>(m_maxLoadFactor);
//        ExpandableHashMap<KeyType, ValueType> temp(m_maxLoadFactor);
//        int initSize = m_values.size();
//        for(int i = 8; i < initSize*2; i++){
//            temp.m_values.push_back(nullptr);
//        }
//        //std::cerr << "Reached 117:" << std::endl;
//        //TODO
//        //I think the problem is that its not linking properly when rhashing or something
//        for(int i = 0; i < m_values.size(); i++){
//            if(m_values[i] != nullptr){
//                //Basically what this does is that if there is a linkedlist of size greater than one at a given spot in the old hash map m_values[i], it rehashes all of these links into the temp hash map.
//                Node* currOld = m_values[i];
//                while(currOld !=nullptr){
//                    //temp.m_values[getBucketNumber(curr->m_key)] = curr->m_value;
//                    Node* currNew = new Node(currOld->m_value, currOld->m_key);
//                    if(temp.m_values[temp.getBucketNumber(currOld->m_key)] != nullptr){
//                        currNew->m_next = temp.m_values[temp.getBucketNumber(currOld->m_key)];
//                        temp.m_values[temp.getBucketNumber(currOld->m_key)] = currNew;
//                    }
//                    else
//                        temp.m_values[temp.getBucketNumber(currOld->m_key)] = currNew;
//                    currOld = currOld->m_next;
//                }
//                //temp.m_values[getBucketNumber(curr->m_key)] = new Node(curr->m_value, curr->m_key);
//            }
//        }
//        //std::cerr << "Reached 136:" << std::endl;
//
//        //Delete all the current values in the data structure
//        //to fix this, try to make this block of code run every time associate is called and not just when rehash is called to see if the problem persists.
//        for(int i = m_values.size()-1; i>=0; i--){
////            m_keys.pop_back();
//            Node* curr = m_values[i];
//            int j = 0;
//            while(curr != nullptr){
//                delete curr;
//                curr = nullptr;
//                curr = m_values[i]->m_next;
//                m_values[i] = m_values[i]->m_next;
//                j++;
//            }
//            m_values.pop_back();
//        }
//        m_values = temp.m_values;
//        //This is to make sure the nodes at the pointers aren't deleted when temps destructor is called since we need them in the other hash map were using
//        for(int i = 0; i < temp.m_values.size(); i++){
//            temp.m_values[i] = nullptr;
//        }
//        //std::cerr << "Reached 150:" << std::endl;
//
//    }
//    //Since the key is not present in the hash map, this adds the key value pair to the hash map
//
//    if(m_values[getBucketNumber(key)] == nullptr)
//        m_values[getBucketNumber(key)] = new Node(value,key);
//    else{
//        Node* curr = new Node(value,key);
//        curr->m_next = m_values[getBucketNumber(key)];
//        m_values[getBucketNumber(key)] = curr;
//        //m_values[getBucketNumber(key)]->m_next = new Node(value,key);
//    }
//
//}
//
//
//// If no association exists with the given key, return nullptr; otherwise,
//// return a pointer to the value associated with that key. This pointer can be
//// used to examine that value, and if the hashmap is allowed to be modified, to
//// modify that value directly within the map (the second overload enables
//// this). Using a little C++ magic, we have implemented it in terms of the
//// first overload, which you must implement.
//template <typename KeyType, typename ValueType>
//const ValueType* ExpandableHashMap<KeyType, ValueType>::find(const KeyType& key) const
//{
//    int h = getBucketNumber(key);
//    Node* curr = m_values[h];
//    if(curr == nullptr)
//        return nullptr;
//    while(curr->m_next !=nullptr){
//        if(curr->m_key == key)
//            return &(curr->m_value);
//        else
//            curr = curr->m_next;
//    }
//    if(curr->m_key == key)
//        return &(curr->m_value);
//    else
//        return nullptr;
//   // return nullptr;  // Delete this line and implement this function correctly
//}
//

// ExpandableHashMap.h

// Skeleton for the ExpandableHashMap class template.  You must implement the first six
// member functions.
#include <iostream>
#include <vector>
#include <list>
#include "provided.h"

template <typename KeyType, typename ValueType>
class ExpandableHashMap
{
public:
    ExpandableHashMap(double maximumLoadFactor = 0.5);
    ~ExpandableHashMap();
    void reset();
    int size() const;
    void associate(const KeyType& key, const ValueType& value);

      // for a map that can't be modified, return a pointer to const ValueType
    const ValueType* find(const KeyType& key) const;

      // for a modifiable map, return a pointer to modifiable ValueType
    ValueType* find(const KeyType& key)
    {
        return const_cast<ValueType*>(const_cast<const ExpandableHashMap*>(this)->find(key));
    }
    unsigned int getBucketNumber(const KeyType& key) const;
      // C++11 syntax for preventing copying and assignment
    ExpandableHashMap(const ExpandableHashMap&) = delete;
    ExpandableHashMap& operator=(const ExpandableHashMap&) = delete;
    
private:
    //size of this returns the number of buckets in a hashmap

    std::vector<std::list<std::pair<KeyType, ValueType> > > m_values;
    //std::vector<KeyType> m_keys;
    //number of keys in the hashmap
    int m_size;
    double m_maxLoadFactor;
};

template <typename KeyType, typename ValueType>
ExpandableHashMap<KeyType, ValueType>::ExpandableHashMap(double maximumLoadFactor){
    m_size = 0;
    if(maximumLoadFactor > 0)
        m_maxLoadFactor = maximumLoadFactor;
    else
        m_maxLoadFactor = 0.5;
    for(int i = 0; i < 8; i++){
        //m_keys.push_back(KeyType());
        std::list<std::pair<KeyType,ValueType> > temp;
        m_values.push_back(temp);
    }
    
}

template <typename KeyType, typename ValueType>
unsigned int ExpandableHashMap<KeyType, ValueType>::getBucketNumber(const KeyType& key) const
{
    unsigned int hasher(const KeyType& k); // prototype
    unsigned int h = hasher(key);
    return h % m_values.size();
}


template <typename KeyType, typename ValueType>
ExpandableHashMap<KeyType, ValueType>::~ExpandableHashMap()
{

}

template <typename KeyType, typename ValueType>
void ExpandableHashMap<KeyType, ValueType>::reset()
{

    std::vector<std::list<std::pair<KeyType, ValueType> > > temp;
    for(int i = 0; i < 8; i++){
        //m_keys.push_back(KeyType());
        std::list<std::pair<KeyType,ValueType> > tempList;
        temp.push_back(tempList);
    }
    m_values = temp;
    std::cerr <<temp.size() << "SIZe" << m_values.size() << std::endl;
    m_size = 0;
}


template <typename KeyType, typename ValueType>
int ExpandableHashMap<KeyType, ValueType>::size() const
{
    //std::cerr << "NBuckets:   " << m_values.size() << " actsize: ";
    return m_size;  // Delete this line and implement this function correctly
}


// The associate method associates one item (key) with another (value).
// If no association currently exists with that key, this method inserts
// a new association into the hashmap with that key/value pair. If there is
// already an association with that key in the hashmap, then the item
// associated with that key is replaced by the second parameter (value).
// Thus, the hashmap must contain no duplicate keys.
template <typename KeyType, typename ValueType>
void ExpandableHashMap<KeyType, ValueType>::associate(const KeyType& key, const ValueType& value)
{
    
    //Checks if there is already a node in the hash map with that key
    if(this->find(key) != nullptr){
        *(this->find(key)) = value;
        return;
    }
    m_size++;
        
    //Checks if the hash map is hitting the load factor and needs to be rehashed
    //std::cerr << "LoadFactor: " <<  m_size/(double)(m_values.size()) << "Size,buckets" << m_size<< ", " << m_values.size() << std::endl;
    
    if(m_size/(double)(m_values.size()) > m_maxLoadFactor){
        //std::cerr <<"Rehashing..." << std::endl;
        ExpandableHashMap<KeyType, ValueType> temp(m_maxLoadFactor);
        int initSize = m_values.size();
       // std::cerr << "initSize" << initSize*2 << std::endl;
        for(int i = 8; i < initSize*2; i++){
            std::list<std::pair<KeyType,ValueType> > tempList;
            temp.m_values.push_back(tempList);
        }

        for(int i = 0; i < m_values.size(); i++){
            for(auto j = m_values[i].begin(); j != m_values[i].end(); j++){
                temp.m_values[temp.getBucketNumber(j->first)].push_back(std::make_pair(j->first,j->second));
            }
        }
        m_values = temp.m_values;
        //This is to make sure the nodes at the pointers aren't deleted when temps destructor is called since we need them in the other hash map were using
    }
    //Since the key is not present in the hash map, this adds the key value pair to the hash map
    m_values[getBucketNumber(key)].push_back(std::make_pair(key,value));
    
}


// If no association exists with the given key, return nullptr; otherwise,
// return a pointer to the value associated with that key. This pointer can be
// used to examine that value, and if the hashmap is allowed to be modified, to
// modify that value directly within the map (the second overload enables
// this). Using a little C++ magic, we have implemented it in terms of the
// first overload, which you must implement.
template <typename KeyType, typename ValueType>
const ValueType* ExpandableHashMap<KeyType, ValueType>::find(const KeyType& key) const
{
    if(m_values.size() == 0)
        return nullptr;
    
    int h = getBucketNumber(key);
    for(auto iter = m_values[h].begin(); iter != m_values[h].end(); iter++){
        if(iter->first == key)
            return &(iter->second);
    }
    return nullptr;
}

