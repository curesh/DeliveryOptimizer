//
//  support.hpp
//  proj4
//
//  Created by Chandra Suresh on 3/8/20.
//  Copyright © 2020 Chandra Suresh. All rights reserved.
//

#ifndef support_h
#define support_h

#include <stdio.h>
#include "provided.h"
#include <math.h>
#include <list>
#include <queue>
//#include <pair>
#include <utility>
#include "ExpandableHashMap.h"
#define _USE_MATH_DEFINES

#endif /* support_h */
